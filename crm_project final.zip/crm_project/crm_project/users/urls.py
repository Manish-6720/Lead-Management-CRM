from django.urls import path
from . import views

app_name = "users"

urlpatterns = [
    # Auth
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),

    # Dashboards
    path("admin-dashboard/", views.admin_dashboard, name="admin_dashboard"),
    path("employee-dashboard/", views.employee_dashboard, name="employee_dashboard"),

    # Employee Management (Admin only)
    path("employees/", views.employee_list, name="employee_list"),
    path("employees/create/", views.employee_create, name="employee_create"),
    path("employees/<int:pk>/edit/", views.employee_edit, name="employee_edit"),
    path("employees/<int:pk>/delete/", views.employee_delete, name="employee_delete"),

    # Lead Management & Account Settings
    path("lead-management/", views.lead_management, name="lead_management"),
    path("account-settings/", views.account_settings, name="account_settings"),

    # OTP based Admin Login
    path("admin-login/", views.login_view, name="admin_login"),  # ✅ fixed
    path("verify-otp/", views.verify_otp, name="verify_otp"),
]
