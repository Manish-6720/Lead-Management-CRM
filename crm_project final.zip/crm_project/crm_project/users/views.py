# users/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.db.models import Count, Q
from django.db.models.functions import TruncDate
from django.utils import timezone
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.conf import settings
from datetime import timedelta, datetime

from .forms import UserCreationForm, EmployeeForm
from .utils import generate_and_send_otp, verify_otp as verify_admin_otp
from leads.models import Lead

User = get_user_model()

# ============================================================================
# CONSTANTS
# ============================================================================
ROLE_ADMIN = "admin"
ROLE_SALES = "sales"
LEADS_PER_PAGE = 20
EMPLOYEES_PER_PAGE = 15
CHART_DAYS_RANGE = 30

# ============================================================================
# ROLE CHECK DECORATORS
# ============================================================================
def is_admin(user):
    """Check if user is authenticated admin"""
    return user.is_authenticated and user.role == ROLE_ADMIN

def is_sales(user):
    """Check if user is authenticated sales person"""
    return user.is_authenticated and user.role == ROLE_SALES

admin_required = user_passes_test(is_admin, login_url='users:login')
sales_required = user_passes_test(is_sales, login_url='users:login')

# ============================================================================
# AUTHENTICATION VIEWS
# ============================================================================
def login_view(request):
    """Handle user login with OTP verification for admins"""
    if request.user.is_authenticated:
        return redirect('users:employee_dashboard' if request.user.role == ROLE_SALES 
                       else 'users:admin_dashboard')
    
    if request.method == "POST":
        phone = request.POST.get("phone", "").strip()
        password = request.POST.get("password", "")
        
        if not phone or not password:
            messages.error(request, "Phone and password are required")
            return render(request, "users/login.html")
        
        user = authenticate(request, username=phone, password=password)
        
        if user:
            if user.role == ROLE_ADMIN:
                # Admin requires OTP verification
                try:
                    otp = generate_and_send_otp(settings.ADMIN_OTP_EMAIL)
                    request.session["pending_admin_user"] = user.id
                    request.session["otp_for"] = user.phone
                    request.session["otp_timestamp"] = timezone.now().isoformat()
                    request.session["otp_sent_message"] = "OTP sent to admin email. Valid for 10 minutes."
                    
                    return redirect("users:verify_otp")
                except Exception as e:
                    messages.error(request, "Failed to send OTP. Please try again.")
                    print(f"OTP send error: {e}")
            else:
                # Sales users login directly
                login(request, user)
                messages.success(request, f"Welcome back, {user.name or user.phone}!")
                return redirect("users:employee_dashboard")
        else:
            messages.error(request, "Invalid phone number or password")
    
    return render(request, "users/login.html")

def verify_otp(request):
    """Verify OTP for admin login"""
    # Display OTP sent message
    otp_sent_msg = request.session.get("otp_sent_message")
    if otp_sent_msg:
        messages.info(request, otp_sent_msg)
        request.session.pop("otp_sent_message", None)
    
    if request.method == "POST":
        entered_otp = request.POST.get("otp", "").strip()
        user_id = request.session.get("pending_admin_user")
        otp_for = request.session.get("otp_for")
        otp_timestamp = request.session.get("otp_timestamp")
        
        # Validate session data
        if not all([user_id, otp_for, otp_timestamp]):
            messages.error(request, "Session expired. Please login again.")
            return redirect("users:login")
        
        # Check OTP expiration (10 minutes)
        otp_time = timezone.datetime.fromisoformat(otp_timestamp)
        if timezone.now() - otp_time > timedelta(minutes=10):
            # Clean up session
            request.session.pop("pending_admin_user", None)
            request.session.pop("otp_for", None)
            request.session.pop("otp_timestamp", None)
            messages.error(request, "OTP expired. Please login again.")
            return redirect("users:login")
        
        # Verify OTP
        if verify_admin_otp(settings.ADMIN_OTP_EMAIL, entered_otp):
            try:
                user = User.objects.get(id=user_id, role=ROLE_ADMIN)
                
                # Clean up session BEFORE login (important!)
                request.session.pop("pending_admin_user", None)
                request.session.pop("otp_for", None)
                request.session.pop("otp_timestamp", None)
                
                # Login user
                login(request, user)
                
                # Set welcome message for dashboard
                messages.success(request, f"Welcome, {user.name or 'Admin'}!")
                return redirect("users:admin_dashboard")
            except User.DoesNotExist:
                messages.error(request, "User not found. Please login again.")
                return redirect("users:login")
        else:
            messages.error(request, "Invalid OTP. Please try again.")
    
    return render(request, "users/verify_otp.html")

@login_required
def logout_view(request):
    """Handle user logout"""
    logout(request)
    messages.success(request, "Logged out successfully")
    return redirect("users:login")

# ============================================================================
# DASHBOARD VIEWS
# ============================================================================
@admin_required
def admin_dashboard(request):
    """Admin dashboard with analytics and charts"""
    today = timezone.now()
    first_day_this_month = today.replace(day=1)
    first_day_last_month = (first_day_this_month - timedelta(days=1)).replace(day=1)
    thirty_days_ago = today - timedelta(days=CHART_DAYS_RANGE)
    
    # Lead statistics
    total_leads = Lead.objects.count()
    converted = Lead.objects.filter(status="converted").count()
    lost = Lead.objects.filter(status="lost").count()
    followups = Lead.objects.filter(status="follow_up").count()
    epc = Lead.objects.filter(status="epc").count()
    employees = User.objects.filter(role=ROLE_SALES).count()
    
    # Monthly conversion comparison
    last_month_converted = Lead.objects.filter(
        status="converted",
        converted_at__gte=first_day_last_month,
        converted_at__lt=first_day_this_month,
    ).count()
    
    this_month_converted = Lead.objects.filter(
        status="converted",
        converted_at__gte=first_day_this_month,
    ).count()
    
    # Leads by source
    leads_by_source = list(
        Lead.objects.values("source")
        .annotate(total=Count("id"))
        .order_by("-total")
    )
    
    # Daily lead creation trend (last 30 days)
    leads_per_day = list(
        Lead.objects.filter(created_at__gte=thirty_days_ago)
        .annotate(day=TruncDate("created_at"))
        .values("day")
        .annotate(total=Count("id"))
        .order_by("day")
    )
    
    context = {
        'total_leads': total_leads,
        'converted': converted,
        'lost': lost,
        'followups': followups,
        'epc': epc,
        'employees': employees,
        'last_month_converted': last_month_converted,
        'this_month_converted': this_month_converted,
        'leads_by_source': leads_by_source,
        'leads_per_day': leads_per_day,
        'chart_days': CHART_DAYS_RANGE,
    }
    
    return render(request, "users/admin_dashboard.html", context)

@login_required
def employee_dashboard(request):
    """Employee dashboard showing assigned leads"""
    status_filter = request.GET.get("status", "").strip()
    
    # Get leads assigned to current user
    leads = Lead.objects.filter(assigned_to=request.user).select_related('assigned_to')
    
    # Apply status filter
    if status_filter and status_filter in dict(Lead.STATUS_CHOICES):
        leads = leads.filter(status=status_filter)
    
    leads = leads.order_by("-created_at")
    
    # Calculate statistics
    all_leads = Lead.objects.filter(assigned_to=request.user)
    stats = {
        "total": all_leads.count(),
        "converted": all_leads.filter(status="converted").count(),
        "follow_up": all_leads.filter(status="follow_up").count(),
        "contacted": all_leads.filter(status="contacted").count(),
        "lost": all_leads.filter(status="lost").count(),
        "epc": all_leads.filter(status="epc").count(),
    }
    
    # Pagination
    paginator = Paginator(leads, LEADS_PER_PAGE)
    page = request.GET.get('page', 1)
    
    try:
        leads_page = paginator.page(page)
    except PageNotAnInteger:
        leads_page = paginator.page(1)
    except EmptyPage:
        leads_page = paginator.page(paginator.num_pages)
    
    context = {
        "leads": leads_page,
        "status_choices": Lead.STATUS_CHOICES,
        "stats": stats,
        "employee_name": request.user.name or request.user.phone,
        "selected_status": status_filter,
    }
    
    return render(request, "users/employee_dashboard.html", context)

# ============================================================================
# EMPLOYEE MANAGEMENT (Admin only)
# ============================================================================
@admin_required
def employee_list(request):
    """List all employees with conversion statistics"""
    # Get filter parameters
    try:
        month = int(request.GET.get("month", timezone.now().month))
        year = int(request.GET.get("year", timezone.now().year))
        
        # Validate month and year
        if not (1 <= month <= 12):
            month = timezone.now().month
        if not (2000 <= year <= 2100):
            year = timezone.now().year
    except (ValueError, TypeError):
        month = timezone.now().month
        year = timezone.now().year
    
    # Get all sales employees
    employees = User.objects.filter(role=ROLE_SALES).order_by('name')
    
    # Calculate conversions by employee for selected month
    converted_by_employee = list(
        Lead.objects.filter(
            status="converted",
            converted_at__year=year,
            converted_at__month=month,
        )
        .values("assigned_to__id", "assigned_to__name", "assigned_to__phone")
        .annotate(total=Count("id"))
        .order_by("-total")
    )
    
    context = {
        "employees": employees,
        "converted_by_employee": converted_by_employee,
        "selected_month": month,
        "selected_year": year,
        "year_range": range(2020, timezone.now().year + 2),
    }
    
    return render(request, "users/employee_list.html", context)

@admin_required
def employee_create(request):
    """Create new employee"""
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            employee = form.save(commit=False)
            
            # Set password if provided
            password = form.cleaned_data.get("password")
            if password:
                employee.set_password(password)
            
            # Ensure role is set to sales
            employee.role = ROLE_SALES
            employee.save()
            
            messages.success(
                request, 
                f"Employee {employee.name or employee.phone} created successfully"
            )
            return redirect("users:employee_list")
        else:
            messages.error(request, "Please correct the errors below")
    else:
        form = EmployeeForm()
    
    return render(request, "users/employee_form.html", {
        "form": form,
        "action": "Create"
    })

@admin_required
def employee_edit(request, pk):
    """Edit existing employee"""
    employee = get_object_or_404(User, pk=pk, role=ROLE_SALES)
    
    if request.method == "POST":
        form = UserCreationForm(request.POST, instance=employee)
        if form.is_valid():
            employee = form.save(commit=False)
            
            # Update password if provided
            new_password = form.cleaned_data.get("password1")
            if new_password:
                employee.set_password(new_password)
            
            employee.save()
            messages.success(request, f"Employee {employee.name} updated successfully")
            return redirect("users:employee_list")
        else:
            messages.error(request, "Please correct the errors below")
    else:
        form = UserCreationForm(instance=employee)
    
    return render(request, "users/employee_form.html", {
        "form": form,
        "action": "Edit",
        "employee": employee
    })

@admin_required
def employee_delete(request, pk):
    """Delete employee with confirmation"""
    employee = get_object_or_404(User, pk=pk, role=ROLE_SALES)
    
    if request.method == "POST":
        employee_name = employee.name or employee.phone
        employee.delete()
        messages.success(request, f"Employee {employee_name} removed successfully")
        return redirect("users:employee_list")
    
    # Show assigned leads count for confirmation
    assigned_leads = Lead.objects.filter(assigned_to=employee).count()
    
    return render(request, "users/confirm_remove.html", {
        "emp": employee,
        "assigned_leads": assigned_leads
    })

# ============================================================================
# LEAD MANAGEMENT (Admin only) - NO PAGINATION
# ============================================================================
@admin_required
def lead_management(request):
    """Advanced lead filtering and management - All leads on single page"""
    # Start with all leads
    leads = Lead.objects.select_related('assigned_to').all()
    
    # Search filter (name, email, phone, city)
    search_query = request.GET.get("q", "").strip()
    if search_query:
        leads = leads.filter(
            Q(name__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(phone__icontains=search_query) |
            Q(city__icontains=search_query)
        )
    
    # Status filter
    status_filter = request.GET.get("status", "").strip()
    if status_filter and status_filter in dict(Lead.STATUS_CHOICES):
        leads = leads.filter(status=status_filter)
    
    # Assignment filter
    assign_filter = request.GET.get("filter", "").strip()
    if assign_filter == "unassigned":
        leads = leads.filter(assigned_to__isnull=True)
    elif assign_filter == "assigned":
        leads = leads.filter(assigned_to__isnull=False)
    
    # Employee filter
    employee_id = request.GET.get("employee", "").strip()
    if employee_id:
        try:
            leads = leads.filter(assigned_to__id=int(employee_id))
        except (ValueError, TypeError):
            pass
    
    # 📅 Date Range Filter (Calendar-based)
    start_date = request.GET.get("start_date", "").strip()
    end_date = request.GET.get("end_date", "").strip()
    
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            leads = leads.filter(created_at__date__gte=start_dt.date())
        except (ValueError, TypeError):
            pass
    
    if end_date:
        try:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            leads = leads.filter(created_at__date__lte=end_dt.date())
        except (ValueError, TypeError):
            pass
    
    # Order by most recent first
    leads = leads.order_by("-created_at")
    
    # ✅ Calculate total count (no pagination, all leads shown)
    total_leads_count = leads.count()
    
    # Get all sales employees for dropdown
    employees = User.objects.filter(role__in=[ROLE_SALES, "employee"]).order_by('name')
    
    context = {
        "leads": leads,  # ✅ All leads, no pagination
        "employees": employees,
        "status_choices": Lead.STATUS_CHOICES,
        "selected_status": status_filter,
        "assign_filter": assign_filter,
        "selected_employee": employee_id,
        "search_query": search_query,
        "start_date": start_date,
        "end_date": end_date,
        "total_results": total_leads_count,
    }
    
    return render(request, "users/lead_management.html", context)

# ============================================================================
# ACCOUNT SETTINGS
# ============================================================================
@login_required
def account_settings(request):
    """User account settings page"""
    user = request.user
    
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        phone = request.POST.get("phone", "").strip()
        
        updated = False
        
        if name and name != user.name:
            user.name = name
            updated = True
        
        if phone and phone != user.phone:
            # Check if phone already exists for another user
            if User.objects.filter(phone=phone).exclude(id=user.id).exists():
                messages.error(request, "Phone number already in use")
            else:
                user.phone = phone
                updated = True
        
        if updated:
            user.save()
            messages.success(request, "Account updated successfully")
        else:
            messages.info(request, "No changes made")
        
        return redirect("users:account_settings")
    
    return render(request, "users/account_settings.html", {"user": user})