from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

User = get_user_model()


class UserAuthTest(TestCase):
    def setUp(self):
        # Create an admin user
        self.admin = User.objects.create_user(
            phone="9999999999",
            password="admin123",
            role="admin",
            name="Admin User"
        )
        # Create an employee user
        self.employee = User.objects.create_user(
            phone="8888888888",
            password="emp123",
            role="employee",
            name="Employee User"
        )

    def test_user_created(self):
        """Check users are created correctly"""
        self.assertEqual(User.objects.count(), 2)
        self.assertEqual(self.admin.role, "admin")
        self.assertEqual(self.employee.role, "employee")

    def test_login_success(self):
        """Admin login with correct password"""
        login = self.client.login(phone="9999999999", password="admin123")
        self.assertTrue(login)

    def test_login_fail(self):
        """Login fails with wrong password"""
        login = self.client.login(phone="9999999999", password="wrongpass")
        self.assertFalse(login)

    def test_admin_role(self):
        """Check admin role has correct value"""
        self.assertEqual(self.admin.role, "admin")

    def test_employee_role(self):
        """Check employee role has correct value"""
        self.assertEqual(self.employee.role, "employee")

    def test_logout(self):
        self.client.login(phone="9876543210", password="pass123")
        response = self.client.get(reverse("users:logout"))  # ✅ named URL use करो
        self.assertEqual(response.status_code, 302) 
  # <-- make sure logout url name is 'logout'
        self.assertEqual(response.status_code, 302)  # redirect after logout
