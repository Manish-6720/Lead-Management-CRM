from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm as BaseUserCreationForm

User = get_user_model()


class UserCreationForm(BaseUserCreationForm):
    """Used for creating users with password1/password2 validation (like Django admin)."""
    class Meta:
        model = User
        fields = ("phone", "name", "role", "is_active", "is_staff")


class UserForm(forms.ModelForm):
    """Simple form with raw password (not recommended for production)."""
    class Meta:
        model = User
        fields = ["phone", "role", "password"]
        widgets = {
            "password": forms.PasswordInput(),
        }


class EmployeeForm(forms.ModelForm):
    """
    Employee creation/edit form with hashed password.
    Password is optional on edit (only updates if provided).
    """
    password = forms.CharField(
        widget=forms.PasswordInput,
        required=False,
        help_text="Leave blank to keep the current password."
    )

    class Meta:
        model = User
        fields = ["name", "phone", "role", "password"]

    def save(self, commit=True):
        user = super().save(commit=False)
        pwd = self.cleaned_data.get("password")
        if pwd:  # agar user ne naya password dala hai
            user.set_password(pwd)
        if commit:
            user.save()
        return user
