import random
from django.core.mail import send_mail
from django.conf import settings
from datetime import datetime, timedelta

# Temporary in-memory OTP store (use cache or DB in production)
OTP_STORE = {}

def generate_and_send_otp(email):
    otp = random.randint(100000, 999999)
    OTP_STORE[email] = {
        "otp": otp,
        "expires": datetime.now() + timedelta(minutes=5)  # 5 minutes expiry
    }
    send_mail(
        subject="Your CRM Admin OTP Code",
        message=f"Your one-time login code is: {otp}\nThis code is valid for 5 minutes.",
        from_email=settings.EMAIL_HOST_USER,
        recipient_list=[email],
    )
    return otp

def verify_otp(email, otp_entered):
    record = OTP_STORE.get(email)
    if not record:
        return False
    if datetime.now() > record["expires"]:
        del OTP_STORE[email]
        return False
    if str(record["otp"]) == str(otp_entered):
        del OTP_STORE[email]
        return True
    return False
