# users/decorators.py
from functools import wraps
from django.http import HttpResponseForbidden

def is_admin(user):
    return user.is_authenticated and getattr(user, "role", "") == "admin"

def is_employee(user):
    return user.is_authenticated and getattr(user, "role", "") == "employee"

def admin_required(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not is_admin(request.user):
            return HttpResponseForbidden("Admins only!")
        return view_func(request, *args, **kwargs)
    return _wrapped

def employee_required(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not is_employee(request.user):
            return HttpResponseForbidden("Employees only!")
        return view_func(request, *args, **kwargs)
    return _wrapped
