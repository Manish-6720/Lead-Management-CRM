#leads/models.py

from django.db import models
from django.conf import settings
from django.contrib.auth import get_user_model

User = get_user_model()

# Mapping for CSV/Excel import
COLUMN_MAP = {
    "full_name": "name",
    "full name": "name",
    "name": "name",

    "email address": "email",
    "email": "email",

    "phone": "phone",
    "phone number": "phone",
    "phone_number": "phone",
    "mobile": "phone",

    "post code": "post_code",
    "post_code": "post_code",
    "zipcode": "post_code",

    "city": "city",

    "county": "region",
    "region": "region",
    "county/region": "region",
}

class Lead(models.Model):
    STATUS_CHOICES = [
        ("new", "New"),
        ("follow_up", "Follow Up"),
        ("contacted", "Contacted"),
        ("converted", "Converted"),
        ("lost", "Lost"),
        ("epc", "EPC"),
    ]

    SOURCE_CHOICES = [
        ("meta", "Meta Ads"),
        ("website", "Website"),
        ("manual", "Manual"),
    ]

    name = models.CharField(max_length=255)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)

    # Extra fields for your dashboard / table
    post_code = models.CharField(max_length=30, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    region = models.CharField(max_length=100, blank=True, null=True)

    source = models.CharField(
        max_length=50,
        choices=SOURCE_CHOICES,
        default="manual"
    )

    # ✅ Assigned_to field — required for filters (assigned/unassigned)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,   # important for unassigned filter
        blank=True
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="new"
    )
    notes = models.TextField(blank=True)  # legacy notes field (optional)
    followup_date = models.DateTimeField(null=True, blank=True)

    # Tracking timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)   # ✅ added
    converted_at = models.DateTimeField(null=True, blank=True)
    # Track last status updates
    last_status_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="status_updated_leads"
    )
    last_status_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} - {self.status}"

    @property
    def latest_note(self):
        """Return the most recent note (if any)."""
        return self.lead_notes.order_by("-created_at").first()

class Note(models.Model):
    lead = models.ForeignKey(
        Lead,
        on_delete=models.CASCADE,
        related_name="lead_notes"
    )
    text = models.TextField()
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Note for {self.lead.name} by {self.created_by}"


