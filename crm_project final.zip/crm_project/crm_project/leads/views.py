import json
import csv
from io import StringIO

from django.conf import settings
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from django.urls import reverse

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.db.models import Count, Q, Prefetch
from django.db.models.functions import TruncDate
from datetime import datetime, timedelta

from users.forms import UserCreationForm, EmployeeForm
from leads.models import Lead, Note
from users.models import User
from leads.forms import LeadForm

User = get_user_model()

# Column mapping
COLUMN_MAP = {
    "full name": "name",
    "full_name": "name",
    "name": "name",
    "customer name": "name",
    "lead name": "name",
    "email address": "email",
    "email": "email",
    "e-mail": "email",
    "mail": "email",
    "phone": "phone",
    "phone number": "phone",
    "phone_number": "phone",
    "mobile": "phone",
    "mobile number": "phone",
    "contact number": "phone",
    "contact": "phone",
    "post code": "post_code",
    "post_code": "post_code",
    "zipcode": "post_code",
    "zip code": "post_code",
    "postal code": "post_code",
    "pincode": "post_code",
    "pin code": "post_code",
    "city": "city",
    "town": "city",
    "location": "city",
    "county": "region",
    "region": "region",
    "county/region": "region",
    "state": "region",
    "province": "region",
}

def try_parse_datetime(value):
    """Try a few common datetime formats and return naive datetime."""
    if not value:
        return None
    value = value.strip()
    formats = [
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%d-%m-%Y %H:%M:%S",
        "%d/%m/%Y %H:%M:%S",
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%d/%m/%Y",
    ]
    try:
        dt = datetime.fromisoformat(value)
        return dt
    except Exception:
        pass
    for fmt in formats:
        try:
            return datetime.strptime(value, fmt)
        except Exception:
            continue
    return None

def get_safe_redirect(request, fallback_name=None, fallback_path=None):
    """Return a safe redirect target."""
    next_url = request.POST.get("next") or request.GET.get("next")
    if next_url:
        return next_url
    referer = request.META.get("HTTP_REFERER")
    if referer:
        return referer
    if fallback_name:
        try:
            return reverse(fallback_name)
        except Exception:
            pass
    if fallback_path:
        return fallback_path
    return "/"

def read_csv_file(file):
    """Read CSV file with multiple encoding attempts and delimiter detection."""
    try:
        print(f"Processing file: {file.name}")
        file.seek(0)
        first_bytes = file.read(4)
        file.seek(0)

        encodings_to_try = []
        if isinstance(first_bytes, bytes):
            if first_bytes.startswith(b'\xff\xfe'):
                encodings_to_try = ['utf-16le', 'utf-16', 'utf-8-sig', 'latin1']
            elif first_bytes.startswith(b'\xfe\xff'):
                encodings_to_try = ['utf-16be', 'utf-16', 'utf-8-sig', 'latin1']
            elif first_bytes.startswith(b'\xef\xbb\xbf'):
                encodings_to_try = ['utf-8-sig', 'utf-8', 'latin1']
            else:
                encodings_to_try = ['utf-8', 'utf-8-sig', 'latin1', 'cp1252', 'iso-8859-1']
        else:
            encodings_to_try = ['utf-8', 'latin1']

        for encoding in encodings_to_try:
            try:
                file.seek(0)
                raw = file.read()
                if isinstance(raw, bytes):
                    try:
                        content = raw.decode(encoding)
                    except Exception:
                        content = raw.decode(encoding, errors="replace")
                else:
                    content = raw

                if content and content.startswith('\ufeff'):
                    content = content[1:]

                csv_file = StringIO(content)

                delimiters = [',', '\t', ';', '|']
                for delim in delimiters:
                    try:
                        csv_file.seek(0)
                        reader = csv.DictReader(csv_file, delimiter=delim)
                        rows = list(reader)
                        if rows and len(rows) > 0:
                            first_row = rows[0]
                            if len(first_row.keys()) > 1:
                                print(f"Successfully read with encoding: {encoding}, delimiter: '{delim}'")
                                print(f"Found {len(rows)} rows")
                                print(f"Headers: {list(first_row.keys())}")
                                return rows, encoding, delim
                    except (csv.Error, UnicodeDecodeError) as e:
                        continue
            except Exception as e:
                print(f"Failed with encoding {encoding}: {str(e)}")
                continue

        raise ValueError("Could not read file with any supported encoding")

    except Exception as e:
        print(f"Error reading file: {str(e)}")
        raise

def process_csv_data(rows):
    """Process and normalize CSV data."""
    if not rows:
        raise ValueError("No data rows found")

    processed_data = []
    print("Processing rows...")
    for row_index, row in enumerate(rows):
        try:
            if row_index < 3:
                print(f"Raw row {row_index + 1}: {row}")

            normalized_row = {}
            for original_key, value in row.items():
                if original_key is None:
                    continue
                clean_key = str(original_key).strip().lower()
                clean_key = clean_key.replace('_', ' ').replace('-', ' ')
                clean_key = ' '.join(clean_key.split())
                mapped_key = COLUMN_MAP.get(clean_key, clean_key)
                clean_value = str(value).strip() if value is not None else ''
                if clean_value and clean_value.lower() not in ['nan', 'null', '']:
                    normalized_row[mapped_key] = clean_value

            if row_index < 3:
                print(f"Normalized row {row_index + 1}: {normalized_row}")

            if 'name' in normalized_row and normalized_row['name']:
                processed_data.append(normalized_row)
            else:
                print(f"Row {row_index + 2}: Missing name field. Available keys: {list(normalized_row.keys())}")

        except Exception as e:
            print(f"Error processing row {row_index + 2}: {str(e)}")
            continue

    print(f"Successfully processed {len(processed_data)} rows with valid names")
    return processed_data

def is_admin(user):
    return user.is_authenticated and getattr(user, "role", None) == "admin"

def is_sales(user):
    return user.is_authenticated and getattr(user, "role", None) == "sales"

admin_required = user_passes_test(is_admin)
sales_required = user_passes_test(is_sales)

def login_view(request):
    if request.method == "POST":
        phone = request.POST.get("phone")
        password = request.POST.get("password")
        user = authenticate(request, username=phone, password=password)
        if user:
            login(request, user)
            if getattr(user, "role", None) == "admin":
                return redirect("users:admin_dashboard")
            return redirect("users:employee_dashboard")
        messages.error(request, "Invalid credentials")
    return render(request, "users/login.html")

@login_required
def logout_view(request):
    logout(request)
    return redirect("users:login")

@admin_required
def admin_dashboard(request):
    total_leads = Lead.objects.count()
    converted = Lead.objects.filter(status="converted").count()
    lost = Lead.objects.filter(status="lost").count()
    followups = Lead.objects.filter(status="follow_up").count()
    epc = Lead.objects.filter(status="epc").count()
    employees = User.objects.filter(role="sales").count()
    

    today = datetime.today()
    first_day_this_month = today.replace(day=1)
    first_day_last_month = (first_day_this_month - timedelta(days=1)).replace(day=1)

    last_month_converted = Lead.objects.filter(
        status="converted",
        created_at__gte=first_day_last_month,
        created_at__lt=first_day_this_month
    ).count()

    this_month_converted = Lead.objects.filter(
        status="converted",
        created_at__gte=first_day_this_month
    ).count()

    leads_by_source = Lead.objects.values("source").annotate(total=Count("id"))

    leads_per_day = (
        Lead.objects.filter(created_at__gte=first_day_this_month)
        .annotate(day=TruncDate("created_at"))
        .values("day")
        .annotate(total=Count("id"))
        .order_by("day")
    )

    context = {
        "total_leads": total_leads,
        "converted": converted,
        "lost": lost,
        "followups": followups,
        "epc": epc,
        "employees": employees,
        "last_month_converted": last_month_converted,
        "this_month_converted": this_month_converted,
        "leads_by_source": leads_by_source,
        "leads_per_day": list(leads_per_day),
    }
    return render(request, "users/admin_dashboard.html", context)

@login_required
def employee_dashboard(request):
    status_filter = request.GET.get("status")
    leads = Lead.objects.filter(assigned_to=request.user).order_by("-created_at")
    if status_filter:
        leads = leads.filter(status=status_filter)

    stats = {
        "total": leads.count(),
        "converted": leads.filter(status="converted").count(),
        "follow_up": leads.filter(status="follow_up").count(),
        "contacted": leads.filter(status="contacted").count(),
        "lost": leads.filter(status="lost").count(),
        "epc": leads.filter(status="epc").count(),

    }

    context = {
        "leads": leads,
        "status_choices": Lead.STATUS_CHOICES,
        "stats": stats,
    }
    return render(request, "users/employee_dashboard.html", context)

@admin_required
def employee_list(request):
    employees = User.objects.filter(role="sales")
    month = request.GET.get("month")
    year = request.GET.get("year")
    today = datetime.today()
    month = int(month) if month else today.month
    year = int(year) if year else today.year

    leads = Lead.objects.filter(
        status="converted",
        created_at__year=year,
        created_at__month=month
    )

    converted_by_employee = (
        leads.values("assigned_to__name")
        .annotate(total=Count("id"))
        .order_by("-total")
    )

    context = {
        "employees": employees,
        "converted_by_employee": converted_by_employee,
        "selected_month": month,
        "selected_year": year,
    }
    return render(request, "users/employee_list.html", context)

@admin_required
def employee_create(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            employee = form.save(commit=False)
            if "password" in form.cleaned_data:
                employee.set_password(form.cleaned_data["password"])
            if not employee.role:
                employee.role = "sales"
            employee.save()
            messages.success(request, "Employee created successfully")
            return redirect("users:employee_list")
    else:
        form = EmployeeForm()
    return render(request, "users/employee_form.html", {"form": form})

@admin_required
def employee_edit(request, pk):
    employee = get_object_or_404(User, pk=pk, role="sales")
    if request.method == "POST":
        form = UserCreationForm(request.POST, instance=employee)
        if form.is_valid():
            employee = form.save(commit=False)
            if form.cleaned_data.get("password1"):
                employee.set_password(form.cleaned_data["password1"])
            employee.save()
            messages.success(request, "Employee updated successfully")
            return redirect("users:employee_list")
    else:
        form = UserCreationForm(instance=employee)
    return render(request, "users/employee_form.html", {"form": form})

@admin_required
def employee_delete(request, pk):
    employee = get_object_or_404(User, pk=pk, role="sales")
    if request.method == "POST":
        employee.delete()
        messages.success(request, "Employee removed successfully")
        return redirect("users:employee_list")
    return render(request, "users/confirm_remove.html", {"emp": employee})

@admin_required
def assign_multiple_leads(request):
    """
    POST handler to assign selected leads (checkboxes) to chosen employee.
    """
    if request.method != "POST":
        messages.error(request, "Invalid request method.")
        return redirect("users:lead_management")

    selected = request.POST.getlist("selected_leads")
    employee_id = request.POST.get("employee_id")

    if not selected:
        messages.error(request, "Please select at least one lead to assign.")
        return redirect(request.META.get("HTTP_REFERER", "users:lead_management"))

    if not employee_id:
        messages.error(request, "Please choose an employee to assign to.")
        return redirect(request.META.get("HTTP_REFERER", "users:lead_management"))

    employee = get_object_or_404(User, pk=employee_id, role="sales")
    Lead.objects.filter(id__in=selected).update(assigned_to=employee)

    messages.success(request, f"{len(selected)} lead(s) assigned to {employee.name or employee.phone}.")
    return redirect(request.META.get("HTTP_REFERER", "users:lead_management"))


@login_required
def lead_list(request):
    if request.user.role == "admin":
        qs = Lead.objects.all()
    else:
        qs = Lead.objects.filter(assigned_to=request.user)

    assign_filter = request.GET.get("filter")
    if assign_filter == "unassigned":
        qs = qs.filter(assigned_to__isnull=True)
    elif assign_filter == "assigned":
        qs = qs.filter(assigned_to__isnull=False)

    q = request.GET.get("q", "").strip()
    employee = request.GET.get("employee")
    status = request.GET.get("status")

    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(email__icontains=q) | Q(phone__icontains=q))

    if employee:
        try:
            qs = qs.filter(assigned_to__id=int(employee))
        except ValueError:
            pass

    if status:
        qs = qs.filter(status=status)

    notes_prefetch = Prefetch("note_set", queryset=Note.objects.order_by("-created_at"), to_attr="_notes")
    qs = qs.prefetch_related(notes_prefetch, "assigned_to")

    employees = User.objects.filter(role="sales") if request.user.role == "admin" else None

    context = {
        "leads": qs.order_by("-created_at"),
        "employees": employees,
        "q": q,
        "selected_employee": employee,
        "selected_status": status,
        "assign_filter": assign_filter,
        "status_choices": Lead.STATUS_CHOICES,
        "query_params": request.GET.urlencode(),
    }
    return render(request, "lead_management.html", context)


@login_required
def lead_detail(request, pk):
    lead = get_object_or_404(Lead, pk=pk)
    notes = Note.objects.filter(lead=lead).order_by("-created_at")
    return render(request, "leads/lead_detail.html", {"lead": lead, "notes": notes})

@login_required
def create_lead(request):
    if request.method == "POST":
        form = LeadForm(request.POST)
        if form.is_valid():
            lead = form.save(commit=False)
            if request.user.role == "sales":
                lead.assigned_to = request.user
            lead.save()
            messages.success(request, "Lead created successfully")
            return redirect("users:lead_management")
    else:
        form = LeadForm()
    return render(request, "leads/lead_form.html", {"form": form})

@login_required
@user_passes_test(lambda u: getattr(u, "role", None) == "admin")
def import_csv(request):
    if request.method == "POST":
        if 'file' not in request.FILES:
            messages.error(request, "Please select a file to upload")
            return render(request, "leads/import.html")

        file = request.FILES["file"]

        if not file.name:
            messages.error(request, "Please select a valid file")
            return render(request, "leads/import.html")

        if not file.name.lower().endswith('.csv'):
            messages.error(request, "Please upload a CSV file only. Convert your Excel file to CSV first.")
            return render(request, "leads/import.html")

        try:
            print(f"Starting import of file: {file.name}")

            rows, encoding, delimiter = read_csv_file(file)
            print(f"File read successfully with encoding: {encoding}, delimiter: '{delimiter}'")

            processed_data = process_csv_data(rows)
            print(f"Processed {len(processed_data)} valid rows")

            if not processed_data:
                messages.error(request, "No valid data found in the file. Ensure there is a 'name' column.")
                return render(request, "leads/import.html")

            success_count = 0
            error_count = 0
            duplicate_count = 0
            errors = []

            for row_index, row_data in enumerate(processed_data):
                try:
                    name = row_data.get('name', '').strip()
                    if not name:
                        error_count += 1
                        errors.append(f"Row {row_index + 2}: Name is empty")
                        continue

                    email = row_data.get('email', '').strip()
                    phone = row_data.get('phone', '').strip()

                    existing_lead = None
                    if email:
                        existing_lead = Lead.objects.filter(email=email).first()
                    if not existing_lead and phone:
                        existing_lead = Lead.objects.filter(phone=phone).first()
                    

                    if existing_lead:
                        duplicate_count += 1
                        continue

                    lead_data = {
                        'name': name,
                        'source': row_data.get('source', 'manual'),
                        'status': row_data.get('status', 'new') or 'new'
                    }

                    if email and '@' in email:
                        lead_data['email'] = email

                    if phone:
                        phone_clean = ''.join(filter(str.isdigit, phone))
                        if len(phone_clean) >= 10:
                            lead_data['phone'] = phone_clean

                    for field in ['post_code', 'city', 'region']:
                        value = row_data.get(field, '').strip()
                        if value:
                            lead_data[field] = value

                    created_field = row_data.get('created_time') or row_data.get('created_at') or row_data.get('created')
                    if created_field:
                        parsed_dt = try_parse_datetime(created_field)
                        if parsed_dt:
                            lead_obj = Lead(**lead_data)
                            if hasattr(lead_obj, "created_at"):
                                lead_obj.created_at = parsed_dt
                            lead_obj.save()
                        else:
                            Lead.objects.create(**lead_data)
                    else:
                        Lead.objects.create(**lead_data)

                    success_count += 1

                except Exception as e:
                    error_count += 1
                    errors.append(f"Row {row_index + 2}: {str(e)}")
                    print(f"Error creating lead: {str(e)}")

            if success_count > 0:
                messages.success(request, f"✅ Successfully imported {success_count} leads")

            if duplicate_count > 0:
                messages.warning(request, f"⚠️ Skipped {duplicate_count} duplicate leads")

            if error_count > 0:
                error_msg = f"❌ Failed to import {error_count} rows"
                if errors:
                    error_msg += f": {'; '.join(errors[:3])}"
                    if len(errors) > 3:
                        error_msg += f" and {len(errors) - 3} more..."
                messages.error(request, error_msg)

            print(f"Import completed: {success_count} success, {error_count} errors, {duplicate_count} duplicates")
            
            return redirect("users:lead_management")

        except Exception as e:
            error_message = f"Error processing file: {str(e)}"
            print(error_message)
            messages.error(request, error_message)
            return render(request, "leads/import.html")

    return render(request, "leads/import.html")

@login_required
def update_lead(request, pk):
    lead = get_object_or_404(Lead, pk=pk)

    if request.method == "POST":
        form = LeadForm(request.POST, instance=lead)
        if form.is_valid():
            form.save()
            return redirect("users:lead_management")
    else:
        form = LeadForm(instance=lead)

    return render(request, "leads/update_lead.html", {"form": form, "lead": lead})

@login_required
def assign_lead(request, pk):
    lead = get_object_or_404(Lead, pk=pk)

    if request.method == "POST":
        employee_id = request.POST.get("employee")
        if employee_id:
            employee = get_object_or_404(User, pk=employee_id)
            lead.assigned_to = employee
            lead.save()
            messages.success(request, f"Lead assigned to {employee.name}.")
        else:
            messages.error(request, "Please select an employee.")

    return redirect("users:lead_management")

@login_required
def add_note(request, pk):
    lead = get_object_or_404(Lead, pk=pk)

    if request.method == "POST":
        note_text = request.POST.get("note")
        if note_text:
            Note.objects.create(lead=lead, text=note_text, created_by=request.user)
            messages.success(request, "Note added successfully.")
        else:
            messages.error(request, "Note cannot be empty.")

        return redirect(f"{reverse('users:employee_dashboard')}?status={request.GET.get('status','')}#lead-{lead.id}")

    return render(request, "leads/add_note.html", {"lead": lead})

@login_required
def update_status(request, pk):
    lead = get_object_or_404(Lead, pk=pk)

    if request.method == "POST":
        new_status = request.POST.get("new_status")
        if new_status and new_status in dict(Lead.STATUS_CHOICES):
            old_status = lead.status
            lead.status = new_status
            lead.last_status_by = request.user
            lead.last_status_at = timezone.now()
            
            if new_status == "converted" and old_status != "converted":
                lead.converted_at = timezone.now()
            
            lead.save()
            messages.success(request, "Status updated successfully ✅")
        else:
            messages.error(request, "Invalid status")

        return redirect(f"{reverse('users:employee_dashboard')}#lead-{lead.id}")

    return redirect("users:employee_dashboard")

@csrf_exempt
def webhook_lead(request):
    """Example webhook endpoint for receiving leads from external systems"""
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            Lead.objects.create(
                name=data.get("name", "Unknown"),
                email=data.get("email"),
                phone=data.get("phone"),
                city=data.get("city"),
                region=data.get("region"),
            )
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)
    return HttpResponseBadRequest("Invalid request")

@login_required
def assign_lead_inline(request, pk):
    """Inline assignment handler with proper field name"""
    lead = get_object_or_404(Lead, pk=pk)
    if request.method == "POST":
        assigned_to_id = request.POST.get("assigned_to")
        if assigned_to_id:
            try:
                lead.assigned_to = get_object_or_404(User, pk=assigned_to_id)
                lead.save()
                messages.success(request, f"Lead assigned to {lead.assigned_to.name}")
            except Exception as e:
                messages.error(request, f"Error assigning lead: {str(e)}")
        else:
            if request.user.role == "admin" or request.user.role == "sales":
                lead.assigned_to = request.user
                lead.save()
                messages.success(request, "Lead assigned to you")
    
    return redirect("users:lead_management")

# ✅ NEW: Export Leads Feature
@login_required
def export_leads(request):
    """
    Export leads to CSV based on current filters.
    Supports filtered export - same filters as lead_management page.
    """
    # Get the same queryset as lead_management
    if request.user.role == "admin":
        qs = Lead.objects.all()
    else:
        qs = Lead.objects.filter(assigned_to=request.user)

    # Apply all filters from GET params
    q = request.GET.get("q")
    if q:
        qs = qs.filter(
            Q(name__icontains=q)
            | Q(email__icontains=q)
            | Q(phone__icontains=q)
            | Q(city__icontains=q)
        )

    status = request.GET.get("status")
    if status:
        qs = qs.filter(status=status)

    assign_filter = request.GET.get("filter")
    if assign_filter == "unassigned":
        qs = qs.filter(assigned_to__isnull=True)
    elif assign_filter == "assigned":
        qs = qs.filter(assigned_to__isnull=False)

    employee = request.GET.get("employee")
    if employee:
        try:
            qs = qs.filter(assigned_to__id=int(employee))
        except ValueError:
            pass

    month = request.GET.get("month")
    year = request.GET.get("year")
    if month and year:
        try:
            qs = qs.filter(
                created_at__month=int(month),
                created_at__year=int(year),
            )
        except ValueError:
            pass

    # Select related to avoid extra queries
    qs = qs.select_related('assigned_to', 'last_status_by').order_by('-created_at')

    # Create CSV response
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="leads_export_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
    
    writer = csv.writer(response)
    
    # Write header row
    writer.writerow([
        'ID',
        'Created Date',
        'Full Name',
        'Email',
        'Phone',
        'Post Code',
        'City',
        'Region',
        'Source',
        'Status',
        'Assigned To',
        'Assignment Status',
        'Last Updated',
        'Last Updated By',
        'Converted At',
    ])
    
    # Write data rows
    for lead in qs:
        writer.writerow([
            lead.id,
            lead.created_at.strftime('%d-%m-%Y %H:%M') if lead.created_at else '',
            lead.name,
            lead.email or '',
            lead.phone or '',
            lead.post_code or '',
            lead.city or '',
            lead.region or '',
            lead.get_source_display(),
            lead.get_status_display(),
            lead.assigned_to.name if lead.assigned_to else 'Unassigned',
            'Assigned' if lead.assigned_to else 'Unassigned',
            lead.last_status_at.strftime('%d-%m-%Y %H:%M') if lead.last_status_at else '',
            lead.last_status_by.name if lead.last_status_by else '',
            lead.converted_at.strftime('%d-%m-%Y %H:%M') if lead.converted_at else '',
        ])
    
    return response





    