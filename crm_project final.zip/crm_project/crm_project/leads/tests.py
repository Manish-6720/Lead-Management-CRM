from django.test import TestCase
from django.contrib.auth import get_user_model
from leads.models import Lead

User = get_user_model()

class LeadModelTest(TestCase):
    def setUp(self):
        self.admin = User.objects.create_user(
            phone="9999999999",
            password="admin123",
            role="admin",
            name="Admin User"
        )
        self.sales = User.objects.create_user(
            phone="8888888888",
            password="sales123",
            role="sales",
            name="Sales User"
        )

    def test_create_lead(self):
        lead = Lead.objects.create(
            name="Test Lead",
            phone="1234567890",
            assigned_to=self.sales
        )
        self.assertEqual(lead.status, "new")
        self.assertIsNone(lead.converted_at)

    def test_convert_lead(self):
        lead = Lead.objects.create(
            name="Test Lead 2",
            phone="9876543210",
            assigned_to=self.sales,
            status="converted"
        )
        self.assertEqual(lead.status, "converted")
