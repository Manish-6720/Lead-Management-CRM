# leads/forms.py
from django import forms
from django.core.exceptions import ValidationError
from .models import Lead


class UploadCSVForm(forms.Form):
    csv_file = forms.FileField()


class LeadForm(forms.ModelForm):  # ✅ Admin use karega
    class Meta:
        model = Lead
        fields = ["name", "email", "phone", "source", "assigned_to", "status", "notes", "followup_date"]

    def clean(self):
        cleaned = super().clean()
        email = cleaned.get("email")
        phone = cleaned.get("phone")

        if email:
            qs = Lead.objects.filter(email__iexact=email)
            if self.instance.pk:  # ignore self on update
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise ValidationError("Lead with this email already exists.")

        if phone:
            qs = Lead.objects.filter(phone__iexact=phone)
            if self.instance.pk:  # ignore self on update
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise ValidationError("Lead with this phone already exists.")

        return cleaned


class LeadStatusForm(forms.ModelForm):  # ✅ Employee use karega
    class Meta:
        model = Lead
        fields = ["status", "notes"]
