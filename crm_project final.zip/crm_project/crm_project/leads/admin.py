from django.contrib import admin
from .models import Lead

@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "status", "source", "assigned_to", "created_at")
    list_filter = ("status", "source")
    search_fields = ("name", "phone", "email")
