
#leads/urls.py
from django.urls import path
from . import views

app_name = "leads"

urlpatterns = [
    path("", views.lead_list, name="lead_list"),
    path("create/", views.create_lead, name="create_lead"),
    path("<int:pk>/", views.lead_detail, name="lead_detail"),
    path("<int:pk>/update/", views.update_lead, name="update_lead"),
    path("<int:pk>/assign/", views.assign_lead, name="assign_lead"),
    path("<int:pk>/add-note/", views.add_note, name="add_note"),
    path("<int:pk>/update-status/", views.update_status, name="update_status"),
    path("webhook/", views.webhook_lead, name="webhook_lead"),
    path("import/", views.import_csv, name="import_csv"),
    path("assign/<int:pk>/", views.assign_lead_inline, name="assign_lead_inline"),
    path("assign-multiple/", views.assign_multiple_leads, name="assign_multiple_leads"),
    
    # ✅ NEW: Export route
    path("export/", views.export_leads, name="export_leads"),
]