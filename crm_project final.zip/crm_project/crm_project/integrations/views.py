from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .models import MetaIntegration, WebsiteIntegration, IntegrationLog
import json

def integrations_page(request):
    return render(request, "integrations/integrations.html")

def meta_connect(request):
    # Redirect to Facebook OAuth
    return redirect("https://www.facebook.com/v17.0/dialog/oauth?...")

def meta_callback(request):
    # Handle OAuth callback, save tokens
    return redirect("integrations:integrations_page")

@csrf_exempt
def meta_webhook(request):
    if request.method == "GET":
        verify_token = request.GET.get("hub.verify_token")
        challenge = request.GET.get("hub.challenge")
        if verify_token == "your_verify_token":
            return HttpResponse(challenge)
        return HttpResponse("Error", status=403)
    if request.method == "POST":
        data = json.loads(request.body)
        IntegrationLog.objects.create(
            user=request.user,
            log_type="webhook",
            action="meta_lead_received",
            message="Lead webhook received",
            metadata=data,
        )
        return HttpResponse("OK")
    return HttpResponse("Invalid", status=400)

@csrf_exempt
def website_webhook(request, client_key):
    if request.method == "POST":
        data = json.loads(request.body)

        # TODO: Client validation (optional: check client_key)
        # Example: WebsiteIntegration.objects.get(client_key=client_key)

        # Save lead in DB
        Lead.objects.create(
            name=data.get("name"),
            email=data.get("email"),
            phone=data.get("phone"),
            city=data.get("city"),
            source="Website"
        )

        return JsonResponse({"status": "success", "data": data})

    return HttpResponse("Invalid", status=400)
