# integrations/models.py

from django.db import models
from django.conf import settings
from django.utils import timezone
import secrets

class MetaIntegration(models.Model):
    """Stores Meta (Facebook + Instagram) integration details"""
    
    STATUS_CHOICES = [
        ('connected', 'Connected'),
        ('disconnected', 'Disconnected'),
        ('expired', 'Token Expired'),
    ]
    
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='meta_integration'
    )
    
    # Facebook Page Details
    page_id = models.CharField(max_length=255, blank=True, null=True)
    page_name = models.CharField(max_length=255, blank=True, null=True)
    page_access_token = models.TextField(blank=True, null=True)  # Encrypted in production
    
    # Instagram Account Details (if linked to FB Page)
    instagram_id = models.CharField(max_length=255, blank=True, null=True)
    instagram_username = models.CharField(max_length=255, blank=True, null=True)
    
    # Token Management
    token_expiry = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='disconnected')
    
    # Sync Tracking
    last_synced_at = models.DateTimeField(null=True, blank=True)
    leads_synced_count = models.IntegerField(default=0)
    
    # Webhook Verification
    webhook_verify_token = models.CharField(max_length=255, blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Meta Integration - {self.user.phone} - {self.status}"
    
    def is_token_valid(self):
        """Check if the access token is still valid"""
        if not self.token_expiry:
            return False
        return timezone.now() < self.token_expiry
    
    def generate_webhook_token(self):
        """Generate a secure webhook verification token"""
        self.webhook_verify_token = secrets.token_urlsafe(32)
        self.save()
        return self.webhook_verify_token


class WebsiteIntegration(models.Model):
    """Stores Website webhook and tracking integration details"""
    
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='website_integration'
    )
    
    # Unique identifier for this client
    client_key = models.CharField(max_length=100, unique=True, editable=False)
    
    # Webhook URL (auto-generated)
    webhook_url = models.CharField(max_length=500, blank=True)
    
    # Tracking Script URL (auto-generated)
    tracking_script_url = models.CharField(max_length=500, blank=True)
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    
    # Tracking
    last_received_at = models.DateTimeField(null=True, blank=True)
    leads_received_count = models.IntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Website Integration - {self.user.phone}"
    
    def save(self, *args, **kwargs):
        # Generate client_key if not exists
        if not self.client_key:
            self.client_key = secrets.token_urlsafe(16)
        
        # Auto-generate webhook URL
        if not self.webhook_url:
            self.webhook_url = f"/integrations/webhook/website/{self.client_key}/"
        
        # Auto-generate tracking script URL
        if not self.tracking_script_url:
            self.tracking_script_url = f"/static/js/tracker.js?client={self.client_key}"
        
        super().save(*args, **kwargs)


class IntegrationLog(models.Model):
    """Log all integration activities for debugging"""
    
    LOG_TYPE_CHOICES = [
        ('meta', 'Meta'),
        ('website', 'Website'),
    ]
    
    ACTION_CHOICES = [
        ('connect', 'Connected'),
        ('disconnect', 'Disconnected'),
        ('sync', 'Synced'),
        ('error', 'Error'),
        ('webhook_received', 'Webhook Received'),
    ]
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='integration_logs'
    )
    
    log_type = models.CharField(max_length=20, choices=LOG_TYPE_CHOICES)
    action = models.CharField(max_length=50, choices=ACTION_CHOICES)
    message = models.TextField()
    metadata = models.JSONField(null=True, blank=True)  # Store additional data
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.log_type} - {self.action} - {self.created_at}"
    
    class Meta:
        ordering = ['-created_at']