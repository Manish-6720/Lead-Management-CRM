from django.urls import path
from . import views

app_name = "integrations"

urlpatterns = [
    path('', views.integrations_page, name='integrations_page'),
    path('meta/connect/', views.meta_connect, name='meta_connect'),
    path('meta/callback/', views.meta_callback, name='meta_callback'),
    path('webhook/meta/', views.meta_webhook, name='meta_webhook'),
    path('webhook/website/<str:client_key>/', views.website_webhook, name='website_webhook'),
]
