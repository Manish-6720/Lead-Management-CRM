# integrations/admin.py

from django.contrib import admin
from .models import MetaIntegration, WebsiteIntegration, IntegrationLog


@admin.register(MetaIntegration)
class MetaIntegrationAdmin(admin.ModelAdmin):
    list_display = [
        'user', 
        'page_name', 
        'status', 
        'instagram_username',
        'leads_synced_count',
        'token_expiry',
        'created_at'
    ]
    list_filter = ['status', 'created_at']
    search_fields = ['user__phone', 'user__name', 'page_name', 'instagram_username']
    readonly_fields = [
        'webhook_verify_token', 
        'leads_synced_count', 
        'last_synced_at',
        'created_at',
        'updated_at'
    ]
    
    fieldsets = (
        ('User', {
            'fields': ('user',)
        }),
        ('Facebook Page', {
            'fields': ('page_id', 'page_name', 'page_access_token', 'status', 'token_expiry')
        }),
        ('Instagram', {
            'fields': ('instagram_id', 'instagram_username')
        }),
        ('Webhook', {
            'fields': ('webhook_verify_token',)
        }),
        ('Statistics', {
            'fields': ('leads_synced_count', 'last_synced_at')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )


@admin.register(WebsiteIntegration)
class WebsiteIntegrationAdmin(admin.ModelAdmin):
    list_display = [
        'user',
        'client_key',
        'status',
        'leads_received_count',
        'last_received_at',
        'created_at'
    ]
    list_filter = ['status', 'created_at']
    search_fields = ['user__phone', 'user__name', 'client_key']
    readonly_fields = [
        'client_key',
        'webhook_url',
        'tracking_script_url',
        'leads_received_count',
        'last_received_at',
        'created_at',
        'updated_at'
    ]
    
    fieldsets = (
        ('User', {
            'fields': ('user',)
        }),
        ('Integration Details', {
            'fields': ('client_key', 'webhook_url', 'tracking_script_url', 'status')
        }),
        ('Statistics', {
            'fields': ('leads_received_count', 'last_received_at')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )


@admin.register(IntegrationLog)
class IntegrationLogAdmin(admin.ModelAdmin):
    list_display = [
        'user',
        'log_type',
        'action',
        'message',
        'created_at'
    ]
    list_filter = ['log_type', 'action', 'created_at']
    search_fields = ['user__phone', 'user__name', 'message']
    readonly_fields = ['user', 'log_type', 'action', 'message', 'metadata', 'created_at']
    
    def has_add_permission(self, request):
        # Logs should only be created programmatically
        return False
    
    def has_change_permission(self, request, obj=None):
        # Logs should not be editable
        return False